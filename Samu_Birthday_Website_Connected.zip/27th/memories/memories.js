// Keep the photos in exactly the order Sofiya provided.
const memories = [
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.15.23 PM.jpeg",
        title: "A Moment With You",
        message: `Samu, if I could keep one thing forever, it would be the feeling I get when I am with you.

You have become such a beautiful part of my life. Even the simplest moments feel special because they have you in them.

Sometimes I wish I could pause time and stay in those little moments with you a little longer.`
    },

    {
        photo: "./WhatsApp Image 2026-10-25 at 2.19.10 PM.jpeg",
        title: "My Favourite Person",
        message: `Out of all the people I could have met in this world, somehow I got you.

You are the person I want to tell everything to, the one whose presence makes ordinary days feel better, and the one who makes my heart feel a little more at home.

You are not just someone I love. You are someone I am genuinely grateful for.`
    },

    {
        photo: "./WhatsApp Image 2026-10-25 at 3.27.30 PM.jpeg",
        title: "A Little Forever",
        message: `I know we cannot keep every moment forever, and maybe that is what makes these memories so precious.

But if there is one thing I hope for, it is that we keep making little memories together.

More laughter, more conversations, more silly moments, more hugs, and more days where I get to choose you all over again.`
    },

    {
        photo: "./WhatsApp Image 2026-10-25 at 2.19.25 PM (1).jpeg",
        title: "You & Me",
        message: `There is something so special about us that I cannot always explain in words.

It is in the little things, the way we talk, the moments we share, and the happiness I feel knowing that you are a part of my life.

I do not need every day to be perfect. I just want the real, imperfect, beautiful version of us.`
    },

    {
        photo: "./WhatsApp Image 2026-10-25 at 2.19.33 PM.jpeg",
        title: "My Safe Place",
        message: `Samu, I hope you always know how much you mean to me.

You are someone I can miss even after just saying goodbye, someone who can make me smile without even trying, and someone whose presence means more to me than you probably realise.

Thank you for being you, and for giving me so many reasons to smile.`
    },

    {
        photo: "./WhatsApp Image 2026-10-25 at 2.15.21 PM.jpeg",
        title: "Always You",
        message: `If I could make one birthday wish for us, it would be to keep finding our way back to each other, no matter how busy life becomes.

I want more memories with you, more little adventures, more late conversations, and more birthdays where I get to remind you how loved you are.

Happy birthday, my Samu.

Out of all the beautiful things life could bring me, I am so glad it brought me you.`
    }
];

// Find the elements on the page.
const mainPage = document.querySelector(".page");
const memoryViewer = document.getElementById("memoryViewer");
const memoryPhoto = document.getElementById("memoryPhoto");
const messageTitle = document.getElementById("messageTitle");
const loveMessage = document.getElementById("loveMessage");
const viewerCounter = document.getElementById("viewerCounter");

const closeButton = document.getElementById("closeButton");
const previousButton = document.getElementById("previousButton");
const nextMemoryButton = document.getElementById("nextMemoryButton");
const nextButton = document.getElementById("nextButton");

let currentMemory = 0;

// Open a selected memory.
function openMemory(index) {
    currentMemory = index;

    mainPage.hidden = true;
    memoryViewer.hidden = false;

    showMemory();

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

// Display the photo and message for the selected memory.
function showMemory() {
    const memory = memories[currentMemory];

    memoryPhoto.src = memory.photo;
    memoryPhoto.alt = memory.title;

    messageTitle.textContent = memory.title;
    loveMessage.textContent = memory.message;

    viewerCounter.textContent =
        `${String(currentMemory + 1).padStart(2, "0")} / 06`;

    previousButton.disabled = currentMemory === 0;
    nextMemoryButton.disabled = currentMemory === memories.length - 1;

    previousButton.style.opacity =
        currentMemory === 0 ? "0.4" : "1";

    nextMemoryButton.style.opacity =
        currentMemory === memories.length - 1 ? "0.4" : "1";
}

// Attach click events to all six cards.
document.querySelectorAll(".memory-card").forEach((card) => {
    card.addEventListener("click", () => {
        const index = Number(card.dataset.memory);
        openMemory(index);
    });
});

// Return to the six memory cards.
closeButton.addEventListener("click", () => {
    memoryViewer.hidden = true;
    mainPage.hidden = false;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});

// Show the previous memory.
previousButton.addEventListener("click", () => {
    if (currentMemory > 0) {
        currentMemory--;
        showMemory();
    }
});

// Show the next memory.
nextMemoryButton.addEventListener("click", () => {
    if (currentMemory < memories.length - 1) {
        currentMemory++;
        showMemory();
    }
});

// Continue to the next page.
// Change this filename if your next page has a different name.
nextButton.addEventListener("click", () => {
    window.location.href = "../boolean/boolean.html";
});

// If a photo cannot load, show a helpful message.
memoryPhoto.addEventListener("error", () => {
    memoryPhoto.alt = "Photo could not be loaded. Please check the filename.";
    memoryPhoto.style.minHeight = "150px";
    memoryPhoto.style.objectFit = "contain";
});