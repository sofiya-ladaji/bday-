const scenes = document.querySelectorAll(".scene");
const sceneNumber = document.getElementById("sceneNumber");
const progressFill = document.getElementById("progressFill");

let currentScene = 1;
let typingTimer = null;

const letterText = `Today, I just want you to know how deeply you are loved.

You are someone who has become so special to me in ways I cannot always explain. Sometimes, even the simplest moments with you mean more to me than the biggest things in the world.

I love the little things about us. The conversations, the laughter, the moments when I miss you, and the happiness I feel when I get to talk to you. Even an ordinary day feels different when you're a part of it.

I hope life gives you every reason to be proud of yourself. I hope you find the courage to chase every dream you have, the strength to face the difficult days, and the peace of knowing that you deserve good things.

And on the days when you doubt yourself, I hope you remember how much you matter.

I cannot promise that I will always find the perfect words, but I can promise that what I feel for you comes from a very real place in my heart.

Thank you for being you. Thank you for the memories we have made and the ones we have yet to create.

Happy Birthday, my love. I hope this new year of your life brings you closer to everything you've been wishing for.

And selfishly, I hope I get to be beside you for many of those moments.

You deserve to feel loved today, tomorrow, and on all the ordinary days in between.`;

function showScene(number) {
    if (number < 1 || number > scenes.length) {
        return;
    }

    clearInterval(typingTimer);
    typingTimer = null;

    scenes.forEach((scene) => {
        scene.classList.remove("active");
    });

    const nextScene = document.getElementById(`scene${number}`);

    nextScene.classList.remove("active");

    // Restart the entrance animation.
    void nextScene.offsetWidth;

    nextScene.classList.add("active");

    currentScene = number;

    sceneNumber.textContent = String(number).padStart(2, "0");
    progressFill.style.width = `${(number / scenes.length) * 100}%`;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

// Buttons that move to the next scene.
document.querySelectorAll("[data-next]").forEach((button) => {
    button.addEventListener("click", () => {
        const next = Number(button.dataset.next);
        showScene(next);
    });
});

// Type out the letter when it is opened.
const openLetterButton = document.getElementById("openLetter");
const letterBody = document.getElementById("letterBody");
const letterContinue = document.getElementById("letterContinue");

openLetterButton.addEventListener("click", () => {
    showScene(3);

    letterBody.textContent = "";
    letterContinue.hidden = true;

    let index = 0;

    typingTimer = setInterval(() => {
        if (index < letterText.length) {
            letterBody.textContent += letterText[index];
            index++;

            // Keep the latest part of the letter visible.
            if (window.innerWidth <= 600) {
                letterBody.scrollIntoView({
                    block: "nearest",
                    behavior: "auto"
                });
            }
        } else {
            clearInterval(typingTimer);
            typingTimer = null;
            letterContinue.hidden = false;
        }
    }, 32);
});

// Continue after the letter has finished typing.
letterContinue.addEventListener("click", () => {
    showScene(4);
});

// Restart the whole experience.
document.getElementById("restartButton").addEventListener("click", () => {
    showScene(1);
});

// Create subtle glowing particles.
const particleContainer = document.getElementById("particles");

for (let i = 0; i < 55; i++) {
    const particle = document.createElement("span");

    particle.className = "particle";
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.animationDuration = `${7 + Math.random() * 13}s`;
    particle.style.animationDelay = `${Math.random() * 12}s`;
    particle.style.opacity = `${0.2 + Math.random() * 0.6}`;

    const size = 1 + Math.random() * 2;
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;

    particleContainer.appendChild(particle);
}

// Create slowly falling burgundy rose petals.
const petalContainer = document.getElementById("petals");

for (let i = 0; i < 13; i++) {
    const petal = document.createElement("span");

    petal.className = "petal";
    petal.style.left = `${Math.random() * 100}%`;
    petal.style.animationDuration = `${12 + Math.random() * 15}s`;
    petal.style.animationDelay = `${Math.random() * 15}s`;
    petal.style.transform = `rotate(${Math.random() * 360}deg)`;

    const width = 8 + Math.random() * 9;
    petal.style.width = `${width}px`;
    petal.style.height = `${width * 1.6}px`;

    petalContainer.appendChild(petal);
}