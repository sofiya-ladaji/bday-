// ======================================
// SAMU'S BIRTHDAY CAKE INTERACTIONS
// ======================================

const candles = document.querySelectorAll(".candle");

const instruction = document.getElementById("cakeInstruction");
const wishMessage = document.getElementById("wishMessage");
const continueButton = document.getElementById("continueButton");
const floatingHearts = document.getElementById("floatingHearts");

let candlesBlownOut = 0;


// ======================================
// CANDLE CLICK
// ======================================

candles.forEach(function (candle) {

    candle.addEventListener("click", function () {

        // Do nothing if this candle is already off
        if (candle.classList.contains("blown")) {
            return;
        }

        candle.classList.add("blown");
        candlesBlownOut++;

        createHeartBurst(candle);

        if (candlesBlownOut === 1) {
            instruction.textContent =
                "one wish sent into the universe ♡";
        }

        if (candlesBlownOut === 2) {
            instruction.textContent =
                "two wishes down, baby! ✨";
        }

        if (candlesBlownOut === 3) {
            instruction.textContent =
                "all your wishes are on their way, Samu! ❤️";

            showBirthdayMessage();
        }

    });

});


// ======================================
// REVEAL BIRTHDAY MESSAGE
// ======================================

function showBirthdayMessage() {

    wishMessage.hidden = false;

    setTimeout(function () {
        wishMessage.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });
    }, 250);

    createCelebration();

}


// ======================================
// HEART BURST
// ======================================

function createHeartBurst(candle) {

    const rect = candle.getBoundingClientRect();

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + 20;

    const symbols = ["♥", "♡", "✦", "✧"];

    for (let i = 0; i < 10; i++) {

        const heart = document.createElement("span");

        heart.textContent =
            symbols[Math.floor(Math.random() * symbols.length)];

        heart.style.position = "fixed";
        heart.style.left = centerX + "px";
        heart.style.top = centerY + "px";

        heart.style.color =
            Math.random() > 0.5 ? "#bd2929" : "#ffffff";

        heart.style.fontSize =
            (12 + Math.random() * 12) + "px";

        heart.style.pointerEvents = "none";
        heart.style.zIndex = "9999";

        document.body.appendChild(heart);

        const angle = Math.random() * Math.PI * 2;
        const distance = 40 + Math.random() * 65;

        const dx = Math.cos(angle) * distance;
        const dy = Math.sin(angle) * distance;

        heart.animate(
            [
                {
                    transform: "translate(-50%, -50%) scale(0.5)",
                    opacity: 1
                },
                {
                    transform:
                        `translate(calc(-50% + ${dx}px),
                                   calc(-50% + ${dy}px))
                         scale(1.3)`,
                    opacity: 0
                }
            ],
            {
                duration: 900 + Math.random() * 300,
                easing: "ease-out"
            }
        );

        setTimeout(function () {
            heart.remove();
        }, 1300);

    }

}


// ======================================
// FLOATING BACKGROUND HEARTS
// ======================================

function createFloatingHeart() {

    const heart = document.createElement("span");

    heart.className = "floating-heart";

    heart.textContent =
        Math.random() > 0.5 ? "♡" : "♥";

    heart.style.left = Math.random() * 100 + "%";

    heart.style.fontSize =
        (10 + Math.random() * 14) + "px";

    heart.style.animationDuration =
        (9 + Math.random() * 9) + "s";

    floatingHearts.appendChild(heart);

    setTimeout(function () {
        heart.remove();
    }, 19000);

}

for (let i = 0; i < 12; i++) {
    setTimeout(createFloatingHeart, i * 300);
}

setInterval(createFloatingHeart, 1100);


// ======================================
// BIRTHDAY CELEBRATION
// ======================================

function createCelebration() {

    for (let i = 0; i < 45; i++) {

        const particle = document.createElement("span");

        particle.textContent =
            Math.random() > 0.5 ? "♥" : "✦";

        particle.style.position = "fixed";
        particle.style.left = Math.random() * 100 + "vw";
        particle.style.top = "-20px";

        particle.style.fontSize =
            (10 + Math.random() * 12) + "px";

        particle.style.color =
            Math.random() > 0.5 ? "#bd2929" : "#ffffff";

        particle.style.pointerEvents = "none";
        particle.style.zIndex = "9999";

        document.body.appendChild(particle);

        const duration = 1800 + Math.random() * 2400;

        particle.animate(
            [
                {
                    transform: "translateY(0) rotate(0deg)",
                    opacity: 1
                },
                {
                    transform:
                        `translateY(${window.innerHeight + 80}px)
                         rotate(${Math.random() * 500}deg)`,
                    opacity: 0
                }
            ],
            {
                duration: duration,
                easing: "ease-in"
            }
        );

        setTimeout(function () {
            particle.remove();
        }, duration);

    }

}


// ======================================
// CONTINUE TO NEXT PAGE
// ======================================

continueButton.addEventListener("click", function () {
    window.location.href = "letter/letter.html";
});