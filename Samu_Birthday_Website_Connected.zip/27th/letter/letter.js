// Get page elements

const envelopeContainer = document.getElementById("envelopeContainer");
const openLetterBtn = document.getElementById("openLetterBtn");

const loveGame = document.getElementById("loveGame");
const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");
const buttonArea = document.getElementById("buttonArea");
const gameMessage = document.getElementById("gameMessage");

const secretSection = document.getElementById("secretSection");
const revealSecretBtn = document.getElementById("revealSecretBtn");
const secretMessage = document.getElementById("secretMessage");
const showLetterBtn = document.getElementById("showLetterBtn");

const letterSection = document.getElementById("letterSection");
const continueBtn = document.getElementById("continueBtn");


// PART 1: OPEN THE ENVELOPE

openLetterBtn.addEventListener("click", function () {

    envelopeContainer.classList.add("open");

    openLetterBtn.textContent = "A Little Surprise for You ❤️";
    openLetterBtn.disabled = true;

    setTimeout(function () {

        loveGame.classList.remove("hidden");

        loveGame.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });

    }, 1000);

});


// PART 2: THE YES BUTTON GAME

let dodgeCount = 0;

const funnyMessages = [
    "Hehehe! Try again, baby! 😂💋",
    "Areee, my love! You have to catch it! 😭❤️",
    "Almosttt, handsome! One more try! 😏💋"
];

function moveYesButton() {

    // After three dodges, let him click YES.

    if (dodgeCount >= 3) {
        return;
    }

    dodgeCount++;

    gameMessage.textContent = funnyMessages[dodgeCount - 1];

    // Move the button to a different position
    // inside its button area.

    const areaWidth = buttonArea.clientWidth;
    const areaHeight = buttonArea.clientHeight;

    const maxX = Math.max(0, areaWidth - yesBtn.offsetWidth);
    const maxY = Math.max(0, areaHeight - yesBtn.offsetHeight);

    const randomX = Math.random() * maxX;
    const randomY = Math.random() * maxY;

    yesBtn.style.position = "absolute";
    yesBtn.style.left = randomX + "px";
    yesBtn.style.top = randomY + "px";
    yesBtn.style.transform = "none";
}


// Make YES dodge when he tries to interact with it.
// The button stops dodging after three moves.

yesBtn.addEventListener("pointerenter", function () {

    if (dodgeCount < 3) {
        moveYesButton();
    }

});


// On touchscreens, the first three taps make it dodge.
// The fourth tap can successfully select YES.

yesBtn.addEventListener("click", function () {

    if (dodgeCount < 3) {
        moveYesButton();
        return;
    }

    // He finally caught the YES button!

    gameMessage.innerHTML =
        "I KNEW ITTT! 😭❤️<br>" +
        "Come here, my baby! Sending you a MILLION kisses! 💋💋💋";

    yesBtn.textContent = "YES, I LOVE YOU TOO! ❤️";
    yesBtn.disabled = true;

    noBtn.classList.add("hidden");

    createHeartBurst();

    setTimeout(function () {

        secretSection.classList.remove("hidden");

        secretSection.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    }, 1800);

});


// The NO button gets a funny response.

noBtn.addEventListener("click", function () {

    gameMessage.innerHTML =
        "EXCUSE ME, SIR?! 😭😂<br>" +
        "Wrong answer, handsome! Try that again! ❤️";

    noBtn.textContent = "OKAY, I LOVE YOU! 😂";

});


// PART 3: REVEAL THE SECRET MESSAGE

revealSecretBtn.addEventListener("click", function () {

    secretMessage.classList.remove("hidden");

    revealSecretBtn.textContent = "Your Secret Is Unlocked ❤️";
    revealSecretBtn.disabled = true;

    secretMessage.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

    createHeartBurst();

});


// PART 4: SHOW THE ROMANTIC LETTER

showLetterBtn.addEventListener("click", function () {

    letterSection.classList.remove("hidden");

    letterSection.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

});


// The final button will lead to the next page later.

continueBtn.addEventListener("click", function () {
    window.location.href = "../reasons/reasons.html";
});


// FLOATING BURGUNDY HEARTS

const heartsContainer = document.querySelector(".hearts");

function createHeart() {

    const heart = document.createElement("span");

    heart.classList.add("floating-heart");
    heart.textContent = Math.random() > 0.5 ? "♥" : "♡";

    heart.style.left = Math.random() * 100 + "vw";
    heart.style.fontSize = (12 + Math.random() * 18) + "px";
    heart.style.animationDuration = (6 + Math.random() * 5) + "s";

    heartsContainer.appendChild(heart);

    setTimeout(function () {
        heart.remove();
    }, 11000);

}

setInterval(createHeart, 700);


// HEART BURST WHEN HE CLICKS YES OR OPENS THE SECRET

function createHeartBurst() {

    for (let i = 0; i < 15; i++) {

        const heart = document.createElement("span");

        heart.textContent = ["❤️", "♥", "♡", "💋"][
            Math.floor(Math.random() * 4)
        ];

        heart.style.position = "fixed";
        heart.style.left = (35 + Math.random() * 30) + "vw";
        heart.style.top = (40 + Math.random() * 20) + "vh";
        heart.style.fontSize = (16 + Math.random() * 20) + "px";
        heart.style.pointerEvents = "none";
        heart.style.zIndex = "1000";
        heart.style.transition = "all 1.5s ease";

        document.body.appendChild(heart);

        setTimeout(function () {

            heart.style.transform =
                "translate(" +
                (Math.random() * 300 - 150) +
                "px, -" +
                (100 + Math.random() * 200) +
                "px) rotate(30deg)";

            heart.style.opacity = "0";

        }, 50);

        setTimeout(function () {
            heart.remove();
        }, 1700);

    }

}