const starsContainer = document.getElementById("stars");
const romanceButtons = document.querySelectorAll(".romance-button");

const messageCard = document.getElementById("messageCard");
const messageLabel = document.getElementById("messageLabel");
const messageTitle = document.getElementById("messageTitle");
const messageText = document.getElementById("messageText");
const anotherButton = document.getElementById("anotherButton");

let activeType = "";
let activeMessageIndex = 0;

/* ROMANTIC MESSAGES */

const romanticMessages = {
    hug: {
        title: "A Hug From Me",
        messages: [
            "Come here, baby. Wrap your arms around me and let me hold you close. No rushing, no letting go, just you resting against me while I remind you that you mean the world to me.",
            "If I were beside you right now, I'd pull you into the warmest hug, rest my head against yours, and stay there until all your worries felt a little smaller.",
            "Imagine me holding you so close that you can hear my heartbeat. That's where I'd want you to be, right there in my arms, feeling safe, wanted, and loved."
        ]
    },

    kiss: {
        title: "A Kiss Just for You",
        messages: [
            "I'd gently hold your face, look into your eyes for a second, and give you the sweetest kiss. Then I'd smile at you because I'd probably want another one.",
            "One soft kiss for your birthday, one because I missed you, and one more simply because you're mine to love. Honestly, I don't think I'd stop at just one.",
            "I'd come close, give you a little kiss, and stay near enough to whisper that no birthday gift could ever be as special to me as having you in my life."
        ]
    },

    forehead: {
        title: "A Forehead Kiss",
        messages: [
            "I'd brush your hair away from your forehead, kiss it softly, and tell you that you don't have to be strong every single moment. You deserve love and care, too.",
            "A little forehead kiss from me, followed by a quiet 'I'm proud of you, baby.' I hope you always remember that your dreams matter and I'll always want to see you happy.",
            "I'd kiss your forehead, hold your hand, and remind you that even when the world gets difficult, you deserve gentleness, patience, and someone who celebrates the person you are."
        ]
    },

    cuddle: {
        title: "Stay Close to Me",
        messages: [
            "I want one of those quiet moments where you hold me close, I rest against you, and neither of us needs to say anything. Just your warmth, my hand in yours, and nowhere else we need to be.",
            "Imagine us cuddling under a blanket, talking about absolutely everything and nothing, until we get sleepy. And even then, I'd probably ask you to stay close a little longer.",
            "My perfect little moment would be resting my head on your chest while you play with my hair. I'd close my eyes, smile to myself, and wish time would be a little kinder to us."
        ]
    },

    cheek: {
        title: "One for Your Cheek",
        messages: [
            "I'd give you a quick kiss on the cheek and then act completely innocent, even though I'd be smiling because I know I'd just made you blush.",
            "A little cheek kiss, a gentle squeeze of your hand, and me looking at you like you're the cutest person I've ever seen. Because, honestly, that's exactly how I'd feel.",
            "I'd kiss your cheek, tease you for being adorable, and then pull you back for a hug before you could even think of a comeback."
        ]
    },

    whisper: {
        title: "A Secret for Your Ears Only",
        messages: [
            "I'd lean close and whisper, 'Samu, if you could see yourself through my eyes, you'd understand why my heart keeps choosing you.' Then I'd smile and kiss your cheek.",
            "I'd whisper that you're my favourite person to miss, my favourite person to talk to, and the one I'd want beside me when I have a hundred little things to share.",
            "I'd come close just to tell you a secret: even on the busiest days, there's a little part of my heart that quietly wishes you were right there with me."
        ]
    }
};

/* BACKGROUND STARS */

function createStars() {
    for (let i = 0; i < 75; i++) {
        const star = document.createElement("span");

        star.className = "star";
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        star.style.animationDelay = `${Math.random() * 4}s`;
        star.style.animationDuration = `${2 + Math.random() * 3}s`;

        starsContainer.appendChild(star);
    }
}

createStars();

/* DISPLAY A ROMANTIC MESSAGE */

function displayMessage(type, chooseDifferent = false) {
    const category = romanticMessages[type];

    if (!category) return;

    if (activeType !== type) {
        activeType = type;
        activeMessageIndex = 0;
    } else if (chooseDifferent) {
        activeMessageIndex =
            (activeMessageIndex + 1) % category.messages.length;
    }

    const selectedMessage = category.messages[activeMessageIndex];

    messageLabel.textContent = "A LITTLE SOMETHING FROM ME";
    messageTitle.textContent = category.title;
    messageText.textContent = selectedMessage;

    messageCard.hidden = false;

    // Restart the entrance animation each time a message changes.
    messageCard.style.animation = "none";
    void messageCard.offsetWidth;
    messageCard.style.animation = "";

    messageCard.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });
}

/* HANDLE ROMANTIC BUTTONS */

romanceButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const type = button.dataset.type;

        displayMessage(type);
    });
});

/* SHOW ANOTHER MESSAGE */

anotherButton.addEventListener("click", () => {
    if (activeType) {
        displayMessage(activeType, true);
    }
});

/* CONTINUE TO THE ULTIMATE BIRTHDAY SURPRISE */
const ultimateButton = document.getElementById("ultimateButton");
if (ultimateButton) {
    ultimateButton.addEventListener("click", () => {
        window.location.href = "../ultimate/ultimate.html";
    });
}
