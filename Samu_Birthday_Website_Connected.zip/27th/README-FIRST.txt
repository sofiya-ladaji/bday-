SAMU'S BIRTHDAY WEBSITE
=======================

START HERE:
1. Open index.html in your browser, or use VS Code + Live Server.
2. Click through the pages in order.
3. Keep all folders and photo files together; do not move images out of their folders.

PAGE ORDER:
1. index.html
2. cake.html
3. letter/letter.html
4. reasons/reasons.html
5. memories/memories.html
6. boolean/boolean.html
7. surprise/surprise.html
8. ultimate/ultimate.html

TO TEST ON YOUR COMPUTER:
- Open the whole website folder in VS Code.
- If you have the Live Server extension, right-click index.html and choose "Open with Live Server".

TO SHARE WITH SAMU:
This folder must be published to a static website host before it can be opened from a phone using one link.
When publishing, upload the contents of this folder with index.html at the top level.
Do not share a local file path such as C:\Users\...; it only works on your computer.

NOTES:
- The website uses Google Fonts, so the custom fonts need an internet connection.
- Keep all the supplied photos and folders in place.
