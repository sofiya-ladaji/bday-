// LOVE REASON CARDS

const reasonCards = document.querySelectorAll(".reason-card");
const progressText = document.getElementById("progressText");
const progressBar = document.getElementById("progressBar");

let revealedCards = 0;

reasonCards.forEach(function (card) {

    card.addEventListener("click", function () {

        // Don't count a card more than once.

        if (card.classList.contains("revealed")) {
            return;
        }

        const message = card.dataset.message.trim();

        card.querySelector(".card-message").textContent = message;

        card.classList.add("revealed");

        revealedCards++;

        progressText.textContent =
            "You've discovered " + revealedCards +
            " of 6 little reasons. ❤️";

        progressBar.style.width =
            (revealedCards / reasonCards.length * 100) + "%";

        createHeartBurst();

        if (revealedCards === reasonCards.length) {

            progressText.textContent =
                "You found all 6 reasons! But my love for you has no limit. ❤️";

        }

    });

});


// VIRTUAL HUG

const hugButton = document.getElementById("hugButton");
const hugMessage = document.getElementById("hugMessage");

hugButton.addEventListener("click", function () {

    hugMessage.classList.remove("hidden");

    hugButton.textContent = "One More Hug, Please! 🫂";

    createHeartBurst();

    hugMessage.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

});


// FINAL SURPRISE

const finalButton = document.getElementById("finalButton");

finalButton.addEventListener("click", function () {
    window.location.href = "../memories/memories.html";
});


// FLOATING HEARTS

const heartsContainer = document.querySelector(".hearts");

function createHeart() {

    const heart = document.createElement("span");

    heart.classList.add("floating-heart");

    heart.textContent = Math.random() > 0.5 ? "♥" : "♡";

    heart.style.left = Math.random() * 100 + "vw";

    heart.style.fontSize =
        (12 + Math.random() * 18) + "px";

    heart.style.animationDuration =
        (6 + Math.random() * 5) + "s";

    heartsContainer.appendChild(heart);

    setTimeout(function () {
        heart.remove();
    }, 11000);

}

setInterval(createHeart, 700);


// HEART BURST

function createHeartBurst() {

    for (let i = 0; i < 12; i++) {

        const heart = document.createElement("span");

        heart.textContent = ["❤️", "♥", "♡", "💋"][
            Math.floor(Math.random() * 4)
        ];

        heart.style.position = "fixed";
        heart.style.left = (35 + Math.random() * 30) + "vw";
        heart.style.top = (40 + Math.random() * 20) + "vh";
        heart.style.fontSize = (16 + Math.random() * 20) + "px";
        heart.style.pointerEvents = "none";
        heart.style.zIndex = "1000";
        heart.style.transition = "all 1.5s ease";

        document.body.appendChild(heart);

        setTimeout(function () {

            heart.style.transform =
                "translate(" +
                (Math.random() * 300 - 150) +
                "px, -" +
                (100 + Math.random() * 200) +
                "px) rotate(30deg)";

            heart.style.opacity = "0";

        }, 50);

        setTimeout(function () {
            heart.remove();
        }, 1700);

    }

}