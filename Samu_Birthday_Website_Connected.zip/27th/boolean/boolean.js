const memories = [
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.19.42 PM.jpeg",
        title: "The Way I Love You",
        message: "Sometimes I wish you could live inside my heart for a moment, just to see how beautifully you exist in every little corner of it."
    },
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.19.25 PM.jpeg",
        title: "In Another Lifetime",
        message: "If I had a thousand lives to live, I would spend every one of them finding my way back to you."
    },
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.15.36 PM.jpeg",
        title: "My Heart's Secret",
        message: "There is a little part of me that smiles every time your name appears on my screen, no matter how many times it happens."
    },
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.14.56 PM.jpeg",
        title: "Closer Than Words",
        message: "Even when I don't know how to explain what I feel, my heart somehow knows that it's you."
    },
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.19.09 PM.jpeg",
        title: "If You Were Here",
        message: "If you were beside me right now, I'd hold you a little longer, look at you a little more, and wish the moment would never end."
    },
    {
        photo: "./WhatsApp Image 2026-10-25 at 2.15.41 PM.jpeg",
        title: "My Birthday Wish for Us",
        message: "On your birthday, I don't just wish happiness for you. I wish for more years of loving you, growing with you, and making a thousand little memories that belong only to us."
    }
];

const bubbles = document.querySelectorAll(".bubble");
const popup = document.getElementById("popup");
const popupTitle = document.getElementById("popupTitle");
const popupNumber = document.getElementById("popupNumber");
const popupMessage = document.getElementById("popupMessage");
const popupCounter = document.getElementById("popupCounter");
const couplePhoto = document.getElementById("couplePhoto");
const photoFallback = document.getElementById("photoFallback");

const closeButton = document.getElementById("closeButton");
const previousButton = document.getElementById("previousButton");
const nextButton = document.getElementById("nextButton");
const continueButton = document.getElementById("continueButton");
const sparklesContainer = document.getElementById("sparkles");

let currentIndex = 0;
let isOpening = false;
let lastFocusedElement = null;

/* CREATE SUBTLE BACKGROUND SPARKLES */

function createSparkles() {
    if (!sparklesContainer) return;

    for (let i = 0; i < 65; i++) {
        const sparkle = document.createElement("span");

        sparkle.className = "sparkle";
        sparkle.style.left = `${Math.random() * 100}%`;
        sparkle.style.top = `${Math.random() * 100}%`;
        sparkle.style.animationDelay = `${Math.random() * 4}s`;
        sparkle.style.animationDuration = `${2 + Math.random() * 3}s`;

        sparklesContainer.appendChild(sparkle);
    }
}

createSparkles();

/* CREATE THE BURST PARTICLES */

function burstBubble(bubble) {
    const rect = bubble.getBoundingClientRect();

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    for (let i = 0; i < 24; i++) {
        const particle = document.createElement("span");

        particle.className = "burst-particle";

        particle.style.left = `${centerX}px`;
        particle.style.top = `${centerY}px`;

        const angle = (Math.PI * 2 * i) / 24;
        const distance = 35 + Math.random() * 75;

        const moveX = Math.cos(angle) * distance;
        const moveY = Math.sin(angle) * distance;

        particle.style.setProperty("--move-x", `${moveX}px`);
        particle.style.setProperty("--move-y", `${moveY}px`);

        const size = 2 + Math.random() * 4;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;

        if (Math.random() > 0.5) {
            particle.style.background = "#c98ba0";
            particle.style.boxShadow = "0 0 10px rgba(201, 139, 160, 0.9)";
        }

        document.body.appendChild(particle);

        particle.addEventListener("animationend", () => {
            particle.remove();
        }, { once: true });
    }
}

/* SHOW A MEMORY */

function showMemory(index) {
    currentIndex = (index + memories.length) % memories.length;

    const memory = memories[currentIndex];

    popupTitle.textContent = memory.title;
    popupMessage.textContent = memory.message;
    popupNumber.textContent = "A LITTLE PIECE OF MY HEART";
    popupCounter.textContent =
        `${String(currentIndex + 1).padStart(2, "0")} / ${String(memories.length).padStart(2, "0")}`;

    photoFallback.hidden = true;
    couplePhoto.hidden = true;
    couplePhoto.alt = memory.title;

    // Set a new load handler for the selected image.
    couplePhoto.onload = () => {
        couplePhoto.hidden = false;
        photoFallback.hidden = true;
    };

    couplePhoto.onerror = () => {
        couplePhoto.hidden = true;
        photoFallback.hidden = false;
    };

    // Load the photo from the same folder as boolean.html.
    couplePhoto.src = memory.photo;

    if (couplePhoto.complete && couplePhoto.naturalWidth > 0) {
        couplePhoto.hidden = false;
        photoFallback.hidden = true;
    }

    popup.classList.add("active");
    popup.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
}

/* OPEN POPUP AFTER THE BUBBLE BURSTS */

function openMemory(bubble, index) {
    if (isOpening || bubble.classList.contains("bursting")) return;

    isOpening = true;
    lastFocusedElement = bubble;

    burstBubble(bubble);
    bubble.classList.add("bursting");

    window.setTimeout(() => {
        showMemory(index);

        // Restore the clicked bubble so it can be opened again.
        bubble.classList.remove("bursting");

        isOpening = false;

        closeButton.focus();
    }, 400);
}

/* CLICK ON A BUBBLE */

bubbles.forEach((bubble) => {
    bubble.addEventListener("click", () => {
        const index = Number(bubble.dataset.index);

        if (Number.isInteger(index) && memories[index]) {
            openMemory(bubble, index);
        }
    });
});

/* CLOSE POPUP */

function closePopup() {
    popup.classList.remove("active");
    popup.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";

    if (lastFocusedElement) {
        lastFocusedElement.focus();
    }
}

closeButton.addEventListener("click", closePopup);

/* CLOSE WHEN CLICKING OUTSIDE THE CARD */

popup.addEventListener("click", (event) => {
    if (event.target === popup) {
        closePopup();
    }
});

/* CLOSE WITH ESCAPE KEY */

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && popup.classList.contains("active")) {
        closePopup();
    }
});

/* PREVIOUS AND NEXT MEMORIES */

previousButton.addEventListener("click", () => {
    showMemory(currentIndex - 1);
});

nextButton.addEventListener("click", () => {
    showMemory(currentIndex + 1);
});

/* GO TO THE FINAL SURPRISE PAGE */

continueButton.addEventListener("click", () => {
    window.location.href = "../surprise/surprise.html";
});