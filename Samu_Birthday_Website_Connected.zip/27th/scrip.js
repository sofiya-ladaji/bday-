// ========================================
// FOR MY BABY SAMU 💗
// WELCOME PAGE INTERACTIONS
// ========================================

const envelope = document.getElementById("envelope");
const envelopeButton = document.getElementById("envelopeButton");
const openButton = document.getElementById("openButton");
const loveNote = document.getElementById("loveNote");
const nextButton = document.getElementById("nextButton");
const decorations = document.getElementById("floatingDecorations");

let envelopeOpened = false;


// ========================================
// OPEN ENVELOPE
// ========================================

function openEnvelope() {
    if (!envelopeOpened) {
        envelope.classList.add("opened");
        envelopeOpened = true;

        createHeartBurst(
            window.innerWidth / 2,
            window.innerHeight / 2
        );
    } else {
        envelope.classList.remove("opened");
        envelopeOpened = false;
    }
}

envelopeButton.addEventListener("click", openEnvelope);


// ========================================
// OPEN LOVE NOTE
// ========================================

openButton.addEventListener("click", function () {

    envelope.classList.add("opened");
    envelopeOpened = true;

    loveNote.hidden = false;

    openButton.textContent = "opened with love ♡";

    openButton.disabled = true;
    openButton.style.opacity = "0.7";
    openButton.style.cursor = "default";

    setTimeout(function () {
        loveNote.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });
    }, 150);

    createHeartBurst(
        window.innerWidth / 2,
        window.innerHeight / 2
    );

});


// ========================================
// NEXT BUTTON
// TEMPORARY PLACEHOLDER FOR THE NEXT PAGE
// ========================================

nextButton.addEventListener("click", function () {
    window.location.href = "cake.html";
});


// ========================================
// FLOATING HEARTS AND WHITE SPARKLES
// ========================================

const symbols = ["♡", "♥", "✧", "✦", "⋆", "✩"];

function createFloatingSymbol() {

    const symbol = document.createElement("span");

    symbol.className = "floating-symbol";

    symbol.textContent =
        symbols[Math.floor(Math.random() * symbols.length)];

    symbol.style.left = Math.random() * 100 + "%";

    symbol.style.fontSize =
        (10 + Math.random() * 15) + "px";

    symbol.style.animationDuration =
        (8 + Math.random() * 10) + "s";

    symbol.style.animationDelay =
        (Math.random() * 3) + "s";

    decorations.appendChild(symbol);

    setTimeout(function () {
        symbol.remove();
    }, 20000);

}

// Add decorations at regular intervals

for (let i = 0; i < 18; i++) {
    setTimeout(createFloatingSymbol, i * 250);
}

setInterval(createFloatingSymbol, 650);


// ========================================
// SPARKLES WHEN CLICKING ANYWHERE
// ========================================

document.addEventListener("click", function (event) {

    // Avoid creating duplicate effects on the envelope.
    createClickSparkle(event.clientX, event.clientY);

});

function createClickSparkle(x, y) {

    const sparkle = document.createElement("span");

    sparkle.className = "click-sparkle";

    const sparkleSymbols = ["✧", "♡", "✦", "⋆"];

    sparkle.textContent =
        sparkleSymbols[
            Math.floor(Math.random() * sparkleSymbols.length)
        ];

    sparkle.style.left = x + "px";
    sparkle.style.top = y + "px";

    document.body.appendChild(sparkle);

    setTimeout(function () {
        sparkle.remove();
    }, 1000);

}


// ========================================
// HEART BURST
// ========================================

function createHeartBurst(x, y) {

    const hearts = ["♥", "♡", "✧", "✦"];

    for (let i = 0; i < 14; i++) {

        const heart = document.createElement("span");

        heart.className = "click-sparkle";

        heart.textContent =
            hearts[Math.floor(Math.random() * hearts.length)];

        heart.style.left = x + "px";
        heart.style.top = y + "px";

        heart.style.fontSize =
            (14 + Math.random() * 14) + "px";

        document.body.appendChild(heart);

        const angle = (Math.PI * 2 * i) / 14;

        const distance = 60 + Math.random() * 70;

        const destinationX = Math.cos(angle) * distance;
        const destinationY = Math.sin(angle) * distance;

        heart.animate(
            [
                {
                    transform: "translate(-50%, -50%) scale(0.5)",
                    opacity: 1
                },
                {
                    transform:
                        `translate(
                            calc(-50% + ${destinationX}px),
                            calc(-50% + ${destinationY}px)
                        ) scale(1.4)`,
                    opacity: 0
                }
            ],
            {
                duration: 900 + Math.random() * 400,
                easing: "ease-out"
            }
        );

        setTimeout(function () {
            heart.remove();
        }, 1400);

    }

}